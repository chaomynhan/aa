# vietnamese-password-dicts

 - [wordlist-by-baclv_v2.txt](wordlist-by-baclv_v2.txt) - Wordlist tiếng Việt tổng hợp từ phần mềm [wifi chùa](https://play.google.com/store/apps/details?id=com.bangdev.wifichua&hl=vi) (cập nhật ngày **08/06/2020**)
